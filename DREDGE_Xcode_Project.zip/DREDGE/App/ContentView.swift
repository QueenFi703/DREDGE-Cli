import SwiftUI
import DredgeCore

struct ContentView: View {
    @State private var surfacedInsight = SharedStore.loadSurfaced()
    var body: some View {
        VStack(spacing: 20) {
            Text("DREDGE").font(.largeTitle)
            Button("Process") {
                surfacedInsight = DredgeEngine.process(thoughts: ["A thought emerged"])
                SharedStore.saveSurfaced(surfacedInsight)
            }
            Text(surfacedInsight).italic()
        }.padding()
    }
}
