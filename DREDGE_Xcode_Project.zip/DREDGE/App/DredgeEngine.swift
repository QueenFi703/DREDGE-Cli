import NaturalLanguage

public struct DredgeEngine {
    public static func process(thoughts: [String]) -> String {
        guard !thoughts.isEmpty else { return "Still waters." }
        let text = thoughts.joined(separator: ". ")
        let tagger = NLTagger(tagSchemes: [.sentimentScore])
        tagger.string = text
        let sentiment = tagger.tag(at: text.startIndex, unit: .paragraph, scheme: .sentimentScore).0
        let score = Double(sentiment?.rawValue ?? "0") ?? 0
        if score > 0.3 { return "A gentle clarity is forming." }
        if score < -0.3 { return "Something beneath asks for rest." }
        return "Balance holds."
    }
}
