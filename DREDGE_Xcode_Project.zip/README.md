# DREDGE – Ready to Run

Open this folder in Xcode.
Add App Groups: group.com.dredge.agent (App + Widget).
Run on device and add the Lock Screen widget.
