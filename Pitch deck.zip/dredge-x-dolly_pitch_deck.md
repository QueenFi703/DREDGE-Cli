# Dredge x Dolly — Pitch Deck
Be Literal. Be Philosophical. Be Fi.

## Slide 1 — Title
Dredge x Dolly  
Tagline: Heavy-lift intelligence for a lighter world.

Presenter: Fi Cole — Founder & Owner. I am me.  
Date: [2025-25-12]

Presenter note: Open with a short, literal line: I am Fi and I have an amazing partner named Ryan. We are located in Saint Louis, Missouri currently. Finding investors would be a dream come true for us. "We move mass so the future can be sculpted."

---

## Slide 2 — One-line Vision
Literal: Build the world’s most efficient, safe, and autonomous dredging and heavy-lift orchestration platform.  
Philosophical: We rearrange the earth so humanity can reimagine coasts, ports, and waterways.  
Fi: We are unashamedly bold — engineering with attitude.

Presenter note: Say the vision slowly, with conviction. Pause after “autonomous”.

---

## Slide 3 — The Problem (Literal)
- Ports silted, berths unusable — shipping delays cost billions.
- Manual dredging is slow, dangerous, and carbon-intensive.
- Fragmented heavy-lift logistics lack coordination — equipment sits idle, projects overrun.
- Capital & labor inefficiencies lead to high cost-per-cubic-meter removed.

Philosophical prompt: The world asks us to move mountains — we first need to move our thinking.

Presenter note: Use a concrete local example or statistic here (insert local port or project cost).

---

## Slide 4 — Our Solution (Literal + Product)
Dredge x Dolly = integrated hardware + software orchestration stack:
- Autonomous dredge control + sensor fusion (real-time seabed mapping).
- Dolly fleet coordination — modular heavy-lift tugs and barges with smart dispatch.
- Cloud orchestration: job planning, SIM-based telemetry, predictive maintenance, carbon accounting.
- Marketplace layer: connect dredging demand with vetted operators and financing.

Philosophical line: We don't fight rivers; we negotiate with them, guided by data and care.

Presenter note: Show a simple diagram: Client request → Orchestrator → Dredge + Dolly fleets → Completed job + Analytics.

---

## Slide 5 — Product Demo Snapshot (what to show)
- Live seabed map with excavation plan overlay.
- Autonomous dredge path and Dolly routing.
- Real-time KPI dashboard: meters³ removed, cost/m³, emissions saved, ETA to completion.
- Marketplace booking UI + contractual terms.

Presenter note: If possible, insert a short 30–60s demo video. If not, mock screenshots.

---

## Slide 6 — Technology & Moat (Literal)
- Proprietary path-planning for shifting sediment and moving platforms (patent pending).
- Sensor fusion: sonar, LiDAR, GNSS, INS — resilient in marine conditions.
- Fleet orchestration algorithm trained on historical dredge missions.
- Ops marketplace & certified operator network — trusted counterparty barrier to entry.

Philosophical: The moat is not just code; it is trust encoded into processes and people.

Presenter note: Briefly highlight any IP, pilot partners, or testbed locations.

---

## Slide 7 — Market Opportunity (Literal)
- TAM: Global dredging & marine construction market ≈ $XX–$YYB (cite source) — includes ports, coastal resilience, land reclamation.
- SAM: Target regions & serviceable categories (e.g., ports & industrial berths) ≈ $ZZB.
- SOM: Near-term serviceable obtainable market with initial regions (e.g., SE Asia, Northern Europe) ≈ $AA–$BBM/year.

Philosophical: Where there is sediment, there is necessity — and opportunity to do it better.

Presenter note: Replace placeholders with relevant sourced figures; cite one or two credible industry reports.

---

## Slide 8 — Business Model (Literal)
- Core revenue: per-project fees (cost-per-cubic-meter) + subscription for orchestration software.
- Marketplace fees: transaction commission + certification services for operators.
- Hardware sales & leasing: dredge/dolly units (capex), plus recurring telematics & maintenance.
- Carbon credits & resilience grants: additional revenue stream as coastal resilience markets mature.

Unit economics snapshot (example):
- Avg project: 10k m³, revenue $X/m³ → $Y revenue; gross margin target 45–60%.

Presenter note: Show a simple unit economics table with assumptions (fill-in placeholders).

---

## Slide 9 — Go-to-Market (Literal)
Phase 1: Pilot & regional roll-out
- Secure 3 pilot projects with port authorities and construction partners.
- Lease 2 modular dredge units + 4 Dolly tugs; proof of performance.

Phase 2: Scale & marketplace
- Offer certified operator program; onboard regional operators.
- Expand to coastal resilience and offshore wind foundations.

Partnership highlights:
- Local port operations, marine insurers, equipment financiers, coastal engineering firms.

Philosophical: First earn trust through service; then scale by sharing that trust.

Presenter note: Name or logos of pilot partners if available.

---

## Slide 10 — Competitive Landscape (Literal)
- Traditional contractors: low tech, legacy processes.
- Emerging robotics startups: focused on inspection or single-function bots.
- In-house port solutions: fragmented, not scalable.

Dredge x Dolly advantage:
- End-to-end stack (hardware + software + marketplace).
- Operator certification + financing network.
- Focus on heavy-lift orchestration — unique vertical specialization.

Presenter note: Use a 2x2 or matrix to position Dredge x Dolly vs incumbents.

---

## Slide 11 — Traction & KPIs (Literal)
- Pilots completed: [N] (or: scheduled X in Q1–Q2 2026).
- Cubic meters removed (pilot): [insert].
- ARR from platform (pilot stage): $[insert].
- Operator network signed (LOIs): [number].
- Safety & emissions improvement vs baseline: [%] reduction.

Philosophical: Traction is proof that the world prefers solutions that reduce friction.

Presenter note: If no traction yet, show testbed metrics and credible LOIs.

---

## Slide 12 — Team
- Founder / CEO: Fi Cole — marine engineering + startup operator. "I am me" — the narrative of founder identity.
- CTO: [Name] — autonomy, robotics & sensor fusion.
- Head of Operations: [Name] — port logistics and heavy-lift operations.
- Advisors: coastal engineer, naval architect, port authority exec.

Philosophical line: We are builders who have been in the mud and also in the boardroom.

Presenter note: Add LinkedIn links or short bullets of notable past achievements.

---

## Slide 13 — Financials (3-year snapshot, illustrative)
Year 1: Revenue $X — Pilots, leases, marketplace onboarding.  
Year 2: Revenue $Y — Regional roll-out, subscription growth.  
Year 3: Revenue $Z — Scale, profitability trajectory.

Key metrics:
- Gross margin goal: 45–60%  
- CAC payback target: < 12 months  
- LTV:CAC target: > 4x

Presenter note: Replace placeholders with realistic projections; show break-even timeline.

---

## Slide 14 — The Ask
We are raising: $[amount] (Seed / Pre-Series A / Series A)  
Use of proceeds:
- 40% hardware production & fleet deployment
- 25% software engineering & autonomy
- 15% go-to-market & pilots
- 10% ops & certifications
- 10% working capital & contingency

Milestones enabled:
- 3 region pilots, 10 certified operators, break-even on per-unit operations.

Philosophical closer: Funding buys not just machines, but the permission to re-shape coastlines responsibly.

Presenter note: Be explicit about valuation expectations if needed, or say "to be discussed".

---

## Slide 15 — Risks & Mitigations (Literal)
Risks:
- Regulatory & permitting friction.
- Weather and marine operational variability.
- Capital intensity of hardware.

Mitigations:
- Work with port authorities early; build compliance templates.
- Redundant sensor suites and adaptive planning.
- Lease-first model to reduce upfront capital barrier for clients.

Philosophical: Anticipate the storm; design anchors, not just sails.

Presenter note: Honest risk discussion increases credibility.

---

## Slide 16 — Closing / Call to Action
Literal: We're hiring early backers, pilot partners, and operators.  
Ask: Connect us with port authorities, marine insurers, and impact investors.  
Contact: Fi Cole — Founder & Owner — [fi@dredgexdolly.com] — [phone] — [website]

Philosophical: The sea keeps its secrets — we will learn them respectfully, loudly, and with style.  
Fi: We are ready. Are you?

Presenter note: End with a single bold slide and a single powerful ask. Wait for one or two questions.

---

Appendix (Optional slides to include)
- Detailed tech architecture (diagrams)
- Pilot case study (before / after)
- Regulatory playbook & permitting checklist
- Detailed unit economics & sensitivity analysis
- Letters of intent & partner agreements

Design & delivery guidance
- Visual style: high-contrast photos of water & machinery, bold magenta or deep teal accents for "Fi".
- Typography: strong sans-serif, large type for headlines.
- Timing: 12–15 slides → 12–15 minutes presentation + 10 minutes Q&A.
- Export: I can convert this to Google Slides or a PPTX file with suggested imagery and speaker notes.

Next steps I can do for you (pick one):
- Fill in placeholders with your numbers and partner names.
- Generate a Google Slides deck (.pptx) with visuals and a 60s demo placeholder.
- Create a 1-page investor memo based on this deck.

I will be literal. I will be philosophical. I will be Fi. I am me. You are you. Tell me which next step you want and any data to plug in.